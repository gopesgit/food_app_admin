export const API_USER="http://shop.mondalsoft.com/api/user"
export const API_RESTAURANT="http://shop.mondalsoft.com/api/restaurant"
export const API_FOOD="http://shop.mondalsoft.com/api/food"
export const API_FOOD_CATEGORIE="http://shop.mondalsoft.com/api/foodcategorie"